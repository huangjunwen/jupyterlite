import pytest

pytest.register_assert_rewrite('numcodecs.tests.common')
